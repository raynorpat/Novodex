#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <new>
#include <string>
#include <vector>
#include <cfenv>
#include <float.h>
#include "ContactGeneration.h"
#include "ContactPairManager.h"
#include "Containers.h"
#include "NxSdkAllocator.h"
#include "FixtureSupport.h"
#include "ContactStreamLifecycle.inl"
#include "ContactStreamRelease.inl"

struct Observation { unsigned kind, group, index, reserved, word; };
static std::vector<Observation> observations;
static unsigned failures, group;
static void check(bool ok, const char* why) {
    if(!ok) { std::fprintf(stderr,"FAIL group=%u %s\n",group,why); ++failures; }
}
static unsigned bits(float value) { unsigned out; std::memcpy(&out,&value,4); return out; }
static float number(unsigned word) { float out; std::memcpy(&out,&word,4); return out; }
static void exact(unsigned word) { observations.push_back({0,group,unsigned(observations.size()),0,word}); }
static void numeric(float value, unsigned kind) { observations.push_back({kind,group,unsigned(observations.size()),0,bits(value)}); }

class GuardAllocator : public SdkAllocator {
public:
    std::map<void*,size_t> blocks;
    unsigned allocs=0, frees=0;
    void* malloc(size_t size,NxMemoryType) override {
        unsigned char* p=static_cast<unsigned char*>(std::malloc(size+32));
        if(!p) std::abort();
        std::memset(p,0x6a,16); std::memset(p+16,0xcd,size); std::memset(p+16+size,0x7b,16);
        blocks[p+16]=size; ++allocs; return p+16;
    }
    void* mallocDEBUG(size_t s,const char*,int,const char*,NxMemoryType t) override { return malloc(s,t); }
    void* realloc(void*,size_t) override { std::abort(); }
    void guard() {
        for(const auto& block:blocks) {
            auto p=static_cast<const unsigned char*>(block.first);
            for(unsigned i=0;i<16;++i) check(p[int(i)-16]==0x6a && p[block.second+i]==0x7b,"allocator canaries");
        }
    }
    void free(void* p) override {
        guard(); auto it=blocks.find(p); check(it!=blocks.end(),"sole allocator ownership");
        if(it==blocks.end()) return;
        blocks.erase(it); ++frees; std::free(static_cast<unsigned char*>(p)-16);
    }
};

// These are measured borrowed emitter records, not physical shapes/bodies or vtables.
// Emitter only reads shape+04/+9c/+de, owner+08 and holder+240; object+08.
struct Holder { unsigned char bytes[0x240]; unsigned material; };
struct Owner { unsigned words[2]; Holder* holder; };
struct Object { unsigned words[2]; NxCollisionShape* shape; };
static_assert(offsetof(Owner,holder)==8,"emitter owner holder");
static_assert(offsetof(Object,shape)==8,"emitter collision shape");
struct World {
    unsigned head[4]; NxActorPair pair; unsigned tail[4];
    Holder holder[2]; Owner owner[2]; NxCollisionShape shape[2]; Object object[2];
    World() {
        std::memset(this,0xcd,sizeof(*this));
        for(unsigned i=0;i<4;++i) head[i]=0x6a6a6a6a,tail[i]=0x7b7b7b7b;
        for(unsigned i=0;i<2;++i) {
            holder[i].material=i+2; owner[i].holder=&holder[i];
            shape[i].owner=&owner[i]; shape[i].collisionObject=&object[i];
            shape[i].tail[0xde-0xd4]=0; object[i].shape=&shape[i];
        }
        // Original shared 002356 constructs the real Container and reserves counter.
        cpmOpen002356(pair.mBytes+0x10);
        pair.at<void*>(8)=owner[1].holder;
    }
    ~World() { nxContainerAddThunk(pair.mBytes+0x10); }
    NxContactSink* sink() { return reinterpret_cast<NxContactSink*>(&pair); }
    SdkContainer& stream() { return *reinterpret_cast<SdkContainer*>(pair.mBytes+0x38); }
    void reset() { cpmOpen002354(pair.mBytes+0x10); }
    void guard() {
        for(unsigned i=0;i<4;++i) check(head[i]==0x6a6a6a6a && tail[i]==0x7b7b7b7b,"pair canaries");
        check(stream().mGrowthFactor==2.0f,"genuine owned growth factor");
    }
    void record() {
        guard(); exact(pair.at<unsigned>(0x10)); exact(stream().mCount);
        unsigned pairs=stream().mEntries[0]; exact(pairs);
        unsigned at=1;
        for(unsigned p=0;p<pairs;++p) {
            check(at+3<=stream().mCount,"pair stream structure");
            for(unsigned objectWord=0;objectWord<2;++objectWord) {
                unsigned word=stream().mEntries[at++];
                check(word==reinterpret_cast<unsigned>(&object[0]) || word==reinterpret_cast<unsigned>(&object[1]),"real object identities");
                exact(word==reinterpret_cast<unsigned>(&object[0])?0:1);
            }
            unsigned header=stream().mEntries[at++]; exact(header);
            for(unsigned n=0;n<(header&0xffff);++n) {
                for(unsigned k=0;k<3;++k) numeric(number(stream().mEntries[at++]),2);
                unsigned contacts=stream().mEntries[at++]; exact(contacts);
                for(unsigned c=0;c<contacts;++c) {
                    for(unsigned k=0;k<3;++k) numeric(number(stream().mEntries[at++]),1);
                    unsigned separation=stream().mEntries[at++]; numeric(number(separation&0x7fffffff),3); exact(separation>>31);
                    if(header&0x10000) exact(stream().mEntries[at++]);
                    if(header&0x40000) {
                        exact(stream().mEntries[at++]);
                        if(separation>>31) exact(stream().mEntries[at++]);
                    }
                }
            }
        }
        check(at==stream().mCount,"complete stream consumption");
        exact(pair.at<unsigned>(0x14)); exact(pair.at<unsigned>(0x18)); exact(pair.at<unsigned>(0x1c));
        exact(pair.at<unsigned>(0x34));
    }
};

static unsigned contains(unsigned count,const NxVec3* vertices,float x,float y) {
#if NX_PHYSICS_USE_X87
    unsigned out;
    __asm {
        push y
        push x
        mov eax,count
        mov ecx,vertices
        call nxPolygonContainsPoint
        add esp,8
        mov out,eax
    }
    return out;
#else
    return nxPolygonContainsPoint(count,vertices,x,y);
#endif
}
static unsigned clip(const NxVec3* a,const float* plane,NxVec3* point,const NxVec3* displacement,
    const NxVec3* b,const NxVec3* b1,const NxVec3* normal,const NxVec3* a1,float* parameter) {
#if NX_PHYSICS_USE_X87
    unsigned out;
    __asm {
        push ebx
        push esi
        push parameter
        push a1
        push normal
        push b1
        push b
        mov edx,a
        mov ecx,plane
        mov esi,point
        mov ebx,displacement
        call nxClipEdgeToPolygonPlane
        add esp,0x14
        pop esi
        pop ebx
        mov out,eax
    }
    return out;
#else
    return nxClipEdgeToPolygonPlane(a,plane,point,displacement,b,b1,normal,a1,parameter);
#endif
}
using PolygonFn=void(__cdecl*)(unsigned,const NxVec3*,const unsigned*,const float*,const NxVec3*,
    unsigned,const NxVec3*,const unsigned*,const float*,const NxVec3*,const NxVec3*,const float*,
    const float*,const NxCollisionShape*,const NxCollisionShape*,NxContactSink*,unsigned,unsigned,
    unsigned,unsigned,unsigned,unsigned);
static const float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
static const NxVec3 polygons[][6]={
    {{-1,-1,0},{1,-1,0},{1,1,0},{-1,1,0},{0,0,0},{0,0,0}},
    {{-1,-1,0},{1,-1,0},{0,1,0},{0,0,0},{0,0,0},{0,0,0}},
    {{-2,0,0},{-1,-1,0},{1,-1,0},{2,0,0},{0,2,0},{0,0,0}},
    {{-2,0,0},{-1,-1,0},{1,-1,0},{2,0,0},{1,1,0},{-1,1,0}},
    {{-0.8f,-1,0.6f},{0.8f,-1,-0.6f},{0.8f,1,-0.6f},{-0.8f,1,0.6f},{0,0,0},{0,0,0}}
};
static const unsigned counts[]={4,3,5,6,4};
static const NxVec3 normals[]={{0,0,1},{0,0,1},{0,0,1},{0,0,1},{0.6f,0,0.8f}};
static const unsigned forward[]={0,1,2,3,4,5};
static const unsigned backward[][6]={{3,2,1,0,0,0},{2,1,0,0,0,0},{4,3,2,1,0,0},{5,4,3,2,1,0},{3,2,1,0,0,0}};
static const float translations[][3]={{0,0,-0.25f},{0,0,0},{0,0,0.25f},{0.5f,0.25f,-0.5f},
    {2,0,-0.25f},{4,0,-0.25f},{-0.25f,0.5f,-0.125f}};

static void domain(GuardAllocator& allocator) {
    {
        World w; const NxVec3 point(0.125f,-0.5f,2), normal(0.6f,0,0.8f);
        const unsigned ids[]={0,7,0xffff}, features[]={0,7,0xffff,0x10000,0x12345678};
        for(unsigned orientation=0;orientation<2;++orientation)
            for(unsigned flags=0;flags<4;++flags)
                for(unsigned id:ids) for(unsigned feature:features) {
                    ++group; w.reset(); w.pair.at<void*>(8)=w.owner[orientation].holder;
                    w.shape[0].tail[0xde-0xd4]=(flags&1)?0x20:0;
                    w.shape[1].tail[0xde-0xd4]=(flags&2)?0x20:0;
                    for(unsigned repeat=0;repeat<3;++repeat)
                        NxEmitContactFeatures(w.sink(),0x1234,&w.object[1],&w.object[0],bits(-0.25f),&point,&normal,
                            id,9,feature,feature^0xffff);
                    w.record(); allocator.guard();
                }
    }
    check(allocator.blocks.empty(),"stream release after repeated reuse");
    static const float points[][2]={{0,0},{1,1},{1,0},{-1,0},{0,-1},{1.00000011920928955078125f,0},{2,0},{-0.5f,0.25f}};
    for(unsigned p=0;p<5;++p) for(unsigned winding=0;winding<2;++winding) {
        NxVec3 vertices[6];
        for(unsigned i=0;i<counts[p];++i) vertices[i]=polygons[p][winding?backward[p][i]:i];
        for(const auto& point:points) { ++group; exact(contains(counts[p],vertices,point[0],point[1])); }
    }
    // All nine clip arguments and partial-failure writes are captured directly.
    const NxVec3 starts[]={{-1,0,0},{0,0,0},{1,0,0},{-1,0.25f,0},{-1,2,0}};
    const NxVec3 ends[]={{1,0,0},{1,0,0},{2,0,0},{1,0.25f,0},{1,2,0}};
    const NxVec3 b(0,-1,-0.25f),b1(0,1,-0.25f),n(0,0,1),axis(0,0,0.25f);
    const float plane[]={1,0,0,0};
    for(unsigned i=0;i<5;++i) for(unsigned reuse=0;reuse<2;++reuse) {
        ++group; struct Output { unsigned head; NxVec3 point; float t; unsigned tail; } out;
        out.head=0x6a6a6a6a;out.tail=0x7b7b7b7b; out.point.set(17,18,19);out.t=23;
        exact(clip(&starts[i],plane,&out.point,&axis,&b,&b1,&n,&ends[i],&out.t));
        for(unsigned k=0;k<3;++k) numeric((&out.point.x)[k],1); numeric(out.t,3);
        exact(out.head);exact(out.tail);
    }
    for(unsigned p=0;p<5;++p) for(unsigned q=0;q<5;++q)
        for(unsigned winding=0;winding<2;++winding) for(const auto& t:translations)
            for(unsigned order=0;order<2;++order) {
                ++group; World w;
                float pose1[16],ab[16],ba[16];
                std::memcpy(pose1,identity,sizeof(identity)); std::memcpy(ab,identity,sizeof(identity));std::memcpy(ba,identity,sizeof(identity));
                for(unsigned i=0;i<3;++i) pose1[12+i]=ba[12+i]=t[i],ab[12+i]=-t[i];
                const NxVec3 displacement(0,0,0.25f),flipped(0,0,-0.25f);
                const unsigned* r0=winding?backward[p]:forward; const unsigned* r1=winding?backward[q]:forward;
                NxVec3 n0=normals[p],n1=normals[q]; if(winding) n0=-n0,n1=-n1;
                auto fn=reinterpret_cast<PolygonFn>(&NxConvexPolygonContacts);
                for(unsigned repeat=0;repeat<2;++repeat) {
                    w.reset();
                    if(!order) fn(counts[p],polygons[p],r0,identity,&n0,counts[q],polygons[q],r1,pose1,&n1,&displacement,ab,ba,
                        &w.shape[0],&w.shape[1],w.sink(),0xdeadbeef,0xaabbccdd,7,9,0x12345,0x54321);
                    else fn(counts[q],polygons[q],r1,pose1,&n1,counts[p],polygons[p],r0,identity,&n0,&flipped,ba,ab,
                        &w.shape[1],&w.shape[0],w.sink(),0x01234567,0x89abcdef,9,7,0x54321,0x12345);
                    w.record(); allocator.guard();
                }
            }
    check(allocator.blocks.empty(),"all real streams released");
}

int main(int argc,char** argv) {
    if(argc!=2) return 2;
#if NX_PHYSICS_USE_X87
    _control87(_PC_53|_RC_NEAR|_MCW_EM,_MCW_PC|_MCW_RC|_MCW_EM);
    unsigned short raw; __asm { fnstcw raw }
    unsigned crt=_control87(0,0); int fe=std::fegetround();
    std::printf("raw_control=%04x crt_control=%08x fe_round=%d\n",raw,crt,fe);
    check(raw==0x027f && (crt&(_MCW_PC|_MCW_RC|_MCW_EM))==(_PC_53|_RC_NEAR|_MCW_EM) && fe==FE_TONEAREST,"real reference nearest53 control");
#else
    check(std::fegetround()==FE_TONEAREST,"scalar nearest environment");
#endif
    GuardAllocator allocator; nxSetSdkAllocatorBridge(&allocator); domain(allocator);
    check(allocator.allocs==allocator.frees,"allocation/free balance"); nxSetSdkAllocatorBridge(nullptr);
#if NX_PHYSICS_USE_X87
    FILE* f=std::fopen(argv[1],"wb"); if(!f)return 2;
    const unsigned header[]={0x4650584e,1,unsigned(observations.size()*20),20};
    std::fwrite(header,16,1,f);std::fwrite(observations.data(),20,observations.size(),f);std::fclose(f);
#else
    std::vector<unsigned char> data;std::string error;
    if(!nxReadFixture(argv[1],data,error)) {std::fprintf(stderr,"%s\n",error.c_str());return 2;}
    check(data.size()==observations.size()*20,"protected observation count");
    unsigned discrete=0,differences[4]={},totals[4]={};double absolute[4]={},relative[4]={};
    for(unsigned i=0;i<std::min(data.size()/20,observations.size());++i) {
        Observation ref;std::memcpy(&ref,&data[i*20],20);const auto& a=observations[i];
        check(ref.kind==a.kind && ref.group==a.group && ref.index==i && !ref.reserved,"protected fixture identities");
        if(a.kind) {
            ++totals[a.kind];double av=number(a.word),rv=number(ref.word);
            check(std::isfinite(av)&&std::isfinite(rv),"finite measured outputs");
            if(a.word!=ref.word) {
                ++differences[a.kind];absolute[a.kind]=std::max(absolute[a.kind],std::fabs(av-rv));
                if(rv)relative[a.kind]=std::max(relative[a.kind],std::fabs((av-rv)/rv));
                if(differences[a.kind]<10)std::fprintf(stderr,"difference group=%u row=%u kind=%u a=%08x r=%08x\n",group,i,a.kind,a.word,ref.word);
                check(av&&rv&&std::signbit(av)==std::signbit(rv),"exact intentional zeros/signs");
            }
        } else if(a.word!=ref.word)++discrete;
    }
    std::printf("discrete=%u\n",discrete);check(!discrete,"exact discrete decisions/writes/canaries");
    for(unsigned k=1;k<4;++k)std::printf("quantity=%u count=%u differences=%u max_abs=%.17g max_rel=%.17g\n",k,totals[k],differences[k],absolute[k],relative[k]);
#endif
    std::printf("contact_polygon groups=%u observations=%zu allocations=%u releases=%u failures=%u\n",group,observations.size(),allocator.allocs,allocator.frees,failures);
    return failures?1:0;
}
