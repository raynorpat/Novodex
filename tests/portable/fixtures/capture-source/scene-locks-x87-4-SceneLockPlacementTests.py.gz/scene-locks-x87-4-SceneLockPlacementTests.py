"""Actual production state/link lifetime and legal guard routing source gate."""
import pathlib
root=pathlib.Path(__file__).resolve().parents[2]
scene=(root/'Physics/src/NpScene.cpp').read_text()
assert 'nxSceneLockCreate()' in scene, 'scalar NpScene lacks actual ReadWriteLock producer'
assert 'nxSceneLockDestroy(mWriteLock)' in scene and 'nxSceneLockDestroy(mReadLock)' in scene
unit=(root/'Physics/src/ReadWriteLockScalar.cpp').read_text()
assert 'new (memory) ReadWriteLockData' in unit, 'actual state lifetime missing'
assert 'new (memory) ReadWriteLock' in unit, 'actual link lifetime missing'
assert '->~ReadWriteLockData()' in unit and '->~ReadWriteLock()' in unit
assert 'static_cast<ReadWriteLock*>(link)->lock()' in unit
assert 'static_cast<ReadWriteLock*>(link)->tryLock()' in unit
assert 'static_cast<ReadWriteLock*>(link)->unlock()' in unit
guards=(root/'Physics/src/include/NpSceneGuard.h').read_text()
scalar=guards.split('#else',1)[1].split('#endif',1)[0]
assert 'reinterpret_cast' not in scalar and 'CRITICAL_SECTION' not in scalar
assert 'void nxNpSceneGuardEnter(void* link);' in scalar
print('actual Scene lock lifetime/typed guard source PASS')
